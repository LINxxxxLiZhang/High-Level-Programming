﻿namespace TestEnvt

module Envt =

    open Model.Types

    (* 
     * Replace makeEnvironment below by your own code. 
     * Note that you should delete the given type defintions, which are in module Types
     * Note that your code must all be indented to be contained in module Envt
     *)

    /// dummy environment function which always returns 
    let makeEnvironment () =
        let environment cmd =
            ParseError
        environment


